<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Manage Organization</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
        <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" type="text/css" href="css/manageStudent.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link href="css/sb-admin-2.min.css" rel="stylesheet">
        <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  	     <script src="https://code.jquery.com/jquery-3.3.1.js"
  	        integrity="sha1256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  	        crossorigin="anonymous">
  	         </script>
      <script type="text/javascript" src="js/bootbox.min.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body >
  <?php include'header.php'; ?>
  <div style="
    margin-left: 10px;">
  <main>
    <h1>Manage Students</h1>
  	<div class="form-style-5 slideInDown animated ">
  		<form action ="addStudents.php" method="POST" name="addStudentFrm" id="addStudentFrm">
  			<div class="alert_user"></div>
  			<fieldset>
  				<legend><span class="number">1</span> Student Info</legend>
  				<input type="hidden" name="studentID" id="studentID">
  				<input type="text" name="studentNumber" id="studentNumber" placeholder="Student Number..." required>
  				<input type="text" name="firstName" id="firstName" placeholder="First Name..." required>
  				<input type="text" name="lastName" id="lastName" placeholder="Last Name..." required>
          <label for="Section"><b>Sections</b></label>
                      <select class="sectionSelect" name="sectionSelect" id="sectionSelect" style="color: #000;">
                        <option value="0">All Sections</option>
                        <?php
                          require'connectDB.php';
                          $sql = "SELECT * FROM section_tbl ORDER BY sectionID ASC";
                          $result = mysqli_stmt_init($conn);
                          if (!mysqli_stmt_prepare($result, $sql)) {
                              echo '<p class="error">SQL Error</p>';
                          }
                          else{
                              mysqli_stmt_execute($result);
                              $resultl = mysqli_stmt_get_result($result);
                              while ($row = mysqli_fetch_assoc($resultl)){
                        ?>
                                <option value="<?php echo $row['sectionName'];?>"><?php echo $row['sectionName']; ?></option>
                        <?php
                              }
                          }
                        ?>
                      </select>
  			</fieldset>
  			<fieldset>
  			<legend><span class="number">2</span> Additional Info (Optional)</legend>
  			<label>
          <label for="Section"><b>Organization</b></label>
                      <select class="orgSelect" name="orgSelect" id="orgSelect" style="color: #000;">
                        <option value="0">All Organization </option>
                        <?php
                          require'connectDB.php';
                          $sql = "SELECT * FROM org_tbl ORDER BY orgID ASC";
                          $result = mysqli_stmt_init($conn);
                          if (!mysqli_stmt_prepare($result, $sql)) {
                              echo '<p class="error">SQL Error</p>';
                          }
                          else{
                              mysqli_stmt_execute($result);
                              $resultl = mysqli_stmt_get_result($result);
                              while ($row = mysqli_fetch_assoc($resultl)){
                        ?>
                                <option value="<?php echo $row['orgName'];?>"><?php echo $row['orgName']; ?></option>
                        <?php
                              }
                          }
                        ?>
                      </select>
          <label for="active"><b>Status</b></label>
  	      	</label >
  			</fieldset>
  			<button type="submit" id ="addStudentBtn" name="addStudentBtn" class="btn btn-primary">Add Student</button>
  		</form>
<br>
      <legend><span class="number">3</span> Batch Upload (Optional)</legend>

          <form class="" action="" method="post" enctype="multipart/form-data">
          <input type="file" name="excel" required value="">
          <button type="submit" name="import">Import</button>
        </form>
  	</div>

      <button class="filter-btn btn btn-primary" id="filter-btn">Filter</button>

    <div class="section">
        <!--User table-->
        <div class="table-responsive-md-6 table slideInRight animated" style="max-height: 37.5rem">
          <table class="table">
            <thead class="table-primary">
              <tr>
                <th>Card UID</th>
                <th>Student Number</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Section</th>
                <th>Organization</th>
                <th>Action</th>

              </tr>
            </thead>
            <tbody class="table-secondary">
              <br>
           <?php
                //Connect to database
                require'connectDB.php';
                  $sql = "SELECT * FROM student_tbl ORDER BY studentID DESC";
                  $result = mysqli_query($conn, $sql);
                  while($row = mysqli_fetch_assoc($result))
                  {
                ?>
                            <TR>
                              <td><?php
                              		if ($row['studentID'] == 1) {
                              			echo "<span><i class='glyphicon glyphicon-ok' title='The selected UID'></i></span>";
                              		}
                                  $card_uid = $row['card_uid'];
                              	?>
                              	<form>
                              		<button type="button" class="select_btn" id="<?php echo $card_uid;?>" title="select this UID"><?php echo $card_uid;?></button>
                              	</form></td>
                            <TD><?php echo $row['studentNumber'];?></TD>
                            <TD><?php echo $row['firstName'];?></TD>
                            <TD><?php echo $row['lastName'];?></TD>
                            <TD><?php echo $row['sectionID'];?></TD>
                            <TD><?php echo $row['orgName'];?></TD>
                            <td>
                              <div class="row">
                              <form class="form-left col-6" action="update.php" method="post">
                                <input type="hidden" name="appointmentID" value="<?php echo $row['appointmentID'] ?>"
                                <th> <input type ="submit" name="edit" class = "btn btn-success btn-sm "value ="Edit" /></th>
                              </form>
                              <form class="form-right col-6" action="deleteorg.php" method="post" onsubmit="return confirmDelete()">
                                <input type="hidden" name="orgID" value="<?php echo $row['orgID'] ?>"
                                <th>
                                  <input type ="submit" name="delete" class="btn btn-danger btn-sm" value="Delete" />
                                </th>
                              </form>
                            </div>
                            </td>

                          </TR>

              <?php
                      }
              ?>
            </tbody>
          </table>
        </div>
    </div>

  </main>

  <script type="text/javascript">
  function confirmDelete() {
      if (confirm("Are you sure you want to delete this item?")) {
          return true;
      } else {
          return false;
      }
  }

  </script>
    <script>
    $(document).ready(function(){
    document.getElementById("filter-btn").addEventListener("click", function(){
        $.ajax({
            type: "POST",
            url: "filterStudent.php",
            success: function(response) {
                alert(response);
            }
        });
    });
});

      </script>

  <?php
  		if(isset($_POST["import"])){
  			$fileName = $_FILES["excel"]["name"];
  			$fileExtension = explode('.', $fileName);
        $fileExtension = strtolower(end($fileExtension));
  			$newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

  			$targetDirectory = "uploads/" . $newFileName;
  			move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory);

  			error_reporting(0);
  			ini_set('display_errors', 0);

  			require 'excelReader/excel_reader2.php';
  			require 'excelReader/SpreadsheetReader.php';

  			$reader = new SpreadsheetReader($targetDirectory);
  			foreach($reader as $key => $row){
  				$studNum = $row[0];
  				$fname = $row[1];
  				$lname = $row[2];
  				$section = $row[3];
  				$orgName = $row[4];
  				mysqli_query($conn, "INSERT INTO student_tbl VALUES('', '$studNum', '$fname', '$lname','$section','$orgName','')");
  			}

  			echo
  			"
  			<script>
  			alert('Succesfully Imported');
  			document.location.href = '';
  			</script>
  			";
  		}
  		?>
      </div>
</body>
</html>
