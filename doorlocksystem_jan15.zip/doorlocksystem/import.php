<?php
    if(isset($_POST["import"])){
      $fileName = $_FILES["excel"]["name"];
      $fileExtension = explode('.', $fileName);
      $fileExtension = strtolower(end($fileExtension));
      $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

      $targetDirectory = "uploads/" . $newFileName;
      move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory);

      error_reporting(0);
      ini_set('display_errors', 0);

      require 'excelReader/excel_reader2.php';
      require 'excelReader/SpreadsheetReader.php';

      $reader = new SpreadsheetReader($targetDirectory);
      foreach($reader as $key => $row){
        $studNum = $row[0];
        $fname = $row[1];
        $lname = $row[2];
        $section = $row[3];
        $orgName = $row[4];
        mysqli_query($conn, "INSERT INTO student_tbl VALUES('', '$studNum', '$fname', '$lname','$section','$orgName','')");
      }

      echo
      "
      <script>
      alert('Succesfully Imported');
      document.location.href = '';
      </script>
      ";
    }
    ?>
