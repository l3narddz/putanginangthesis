<?php
require('php-excel-reader/excel_reader2.php');
require('SpreadsheetReader.php');

if(isset($_FILES['excel_file'])){
    try{
        $file_path = $_FILES['excel_file']['tmp_name'];
        $Reader = new SpreadsheetReader($file_path);
        $data = $Reader->toArray();
        $pdo = new PDO('mysql:host=localhost;dbname=rfidattendance','root','password');
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO student_tbl (studentNumber, firstName, lastName, sectionID) VALUES (?, ?, ?, ?)");
        foreach($data as $row) {
            $stmt->bindValue(1, $row[0]);
            $stmt->bindValue(2, $row[1]);
            $stmt->bindValue(3, $row[2]);
            $stmt->bindValue(4, $row[3]);
            $stmt->execute();
        }
        $pdo->commit();
        echo "Data inserted successfully";
    }catch(PDOException $e){
        $pdo->rollback();
        echo "Error inserting data: " . $e->getMessage();
    }
}else{
    echo "No file selected";
}
