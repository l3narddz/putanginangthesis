<?php
  include ('connectDB.php');

  if(isset($_POST['profBtn'])){
    $profName = $_POST['profName'];
    $profEmail = $_POST['profEmail'];
    $profPass = $_POST['profPass'];

    // echo $nameTxt;

    $addProfQuery = "INSERT INTO `prof_tbl`(`profName`, `profEmail`, `profPass`) VALUES
     ('$profName','$profEmail','$profPass')";
    $result = mysqli_query($conn, $addProfQuery);
    if($result)
    {
      echo "Data inserted";
    }else {
      echo "Error";
    }

    // echo $emailTxt;
    // echo $appointmentDateTxt;
    // echo $appointmentTimeTxt;
    // echo $appointmentNotesTxt;

    header("Location: manageProf.php");
    exit();
  }
?>
