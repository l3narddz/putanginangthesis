
<?php
  include ('connectDB.php');

  if(isset($_POST['appointmentBtn'])){
    $nameTxt = $_POST['name'];
    $emailTxt = $_POST['email'];
    $appointmentDateTxt = date('Y-m-d', strtotime($_POST['appointmentDate']));
    $appointmentTimeStartTxt =$_POST['appointmentTimeStart'];
    $appointmentTimeEndTxt =$_POST['appointmentTimeEnd'];
    $appointmentNotesTxt = $_POST['appointmentNotes'];
    $appointtedSections = array('');

    // check for overlap
    $checkOverlapQuery = "SELECT * FROM appointment_tbl WHERE date = '$appointmentDateTxt' AND (timeStart <= '$appointmentTimeEndTxt' AND timeEnd >= '$appointmentTimeStartTxt')";
    $overlapResult = mysqli_query($conn, $checkOverlapQuery);

    if (mysqli_num_rows($overlapResult) > 0) {
        // there is an overlap, do not insert the new appointment
        echo  "<script>alert('Sorry, the selected date is fully booked. Please choose a different date.'); setTimeout(function(){ window.location.href='index.php?error=overlap'; }, 200);</script>";
       exit();
    }
     else {
        // no overlap, insert the new appointment
        $addAppointmentQuery = "INSERT INTO `appointment_tbl`(`name`, `email`, `date`, `timeStart`, `timeEnd`,`reason`, `isActive`) VALUES ('$nameTxt','$emailTxt','$appointmentDateTxt','$appointmentTimeStartTxt','$appointmentTimeEndTxt','$appointmentNotesTxt', 1)";
        $result = mysqli_query($conn, $addAppointmentQuery);
        if($result) {
            $id = mysqli_insert_id($conn);
            foreach($_POST['section'] as $sectionTxt) {
                $addAppointmentSection = "INSERT INTO `appointedsection`(`appointmentId`, `sectionID`) VALUES ('$id','$sectionTxt')";
                mysqli_query($conn, $addAppointmentSection);
            }
        } else {
            echo "Error";
        }
        header("Location: index.php");
        exit();
    }
  }
?>
