<?php
  include ('connectDB.php');

  if(isset($_POST['sectionBtn'])){
    $nameTxt = $_POST['sectionName'];
    $numOfStudentTxt = $_POST['sectionCapacity'];
    $isActive = $_POST['isActive'];
    // check if fields are empty
    if(empty($nameTxt) || empty($numOfStudentTxt) || empty($isActive)){
      echo "<script>alert('Please fill all the fields');</script>";
    }
    else {
      // check if section name already exists
      $checkNameQuery = "SELECT * FROM section_tbl WHERE sectionName = '$nameTxt'";
      $checkNameResult = mysqli_query($conn, $checkNameQuery);
      if (mysqli_num_rows($checkNameResult) > 0) {
          // section name already exists, do not insert new section
          echo "<script>alert('Error: A section with that name already exists.'); setTimeout(function(){ window.location.href='manageSections.php'; }, 200);</script>";
      }
      else {
          // check if sectionCapacity is a number
          if(!is_numeric($numOfStudentTxt)){
              echo "<script>alert('sectionCapacity should be a number');</script>";
          }
          else {
              $addSectionQuery = "INSERT INTO `section_tbl`(`sectionName`, `numberOfstudents`,`isActive`) VALUES ('$nameTxt','$numOfStudentTxt','$isActive')";
              $result = mysqli_query($conn, $addSectionQuery);
              if ($result) {
                  echo "<script>alert('Section added successfully.'); setTimeout(function(){ window.location.href='manageSections.php'; }, 200);</script>";
              } else {
                  echo "<script>alert('Error adding section.'); setTimeout(function(){ window.location.href='manageSections.php'; }, 200);</script>";
              }
          }
      }
    }
  }

?>
