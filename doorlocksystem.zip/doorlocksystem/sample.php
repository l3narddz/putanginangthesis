<!DOCTYPE html>
<html>
<head>
	<title>Student Registration Form</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="/css/manageorg.css">
</head>
<body>
  <?php include 'header.php'; ?>
	<div class="container form-style-5">
		<h1 class="text-center">Student Registration Form</h1>
		<form>
			<div class="form-group">
				<label for="carduid">Card UID</label>
				<input type="text" class="form-control" id="carduid" placeholder="Enter Card UID">
			</div>
			<div class="form-group">
				<label for="username">Username</label>
				<input type="text" class="form-control" id="username" placeholder="Enter Username">
			</div>
			<div class="form-group">
				<label for="firstname">First Name</label>
				<input type="text" class="form-control" id="firstname" placeholder="Enter First Name">
			</div>
			<div class="form-group">
				<label for="lastname">Last Name</label>
        <input type="text" class="form-control" id="lastname" placeholder="Enter Last Name">
			</div>
			<div class="form-group">
				<label for="section">Section</label>
				<input type="text" class="form-control" id="section" placeholder="Enter Section">
			</div>
			<div class="form-group text-center">
				<button type="submit" class="btn btn-primary" id="adduser">Add User</button>
				<button type="submit" class="btn btn-success" id="update">Update</button>
				<button type="submit" class="btn btn-danger" id="delete">Delete</button>
			</div>
		</form>
	</div>
</body>
</html>
