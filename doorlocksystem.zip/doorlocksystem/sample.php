<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <script type="text/javascript">
      function generateCalendar() {
  // Get the current date
  var date = new Date();
  // Get the current month and year
  var month = date.getMonth();
  var year = date.getFullYear();
  // Create a new date object set to the first day of the month
  var firstDay = new Date(year, month, 1);
  // Get the day of the week of the first day (0 = Sunday, 1 = Monday, etc.)
  var firstDayWeekday = firstDay.getDay();
  // Get the number of days in the month
  var numDays = new Date(year, month + 1, 0).getDate();
  // Create a table row for each week
  for (var i = 0; i < 6; i++) {
    var row = document.createElement("tr");
    // Create a table cell for each day of the week
    for (var j = 0; j < 7; j++) {
      var cell = document.createElement("td");
      // Calculate the day number for the cell
      var dayNum = 7 * i + j - firstDayWeekday + 1;
      // Check if the day number is within the range of days in the month
      if (dayNum > 0 && dayNum <= numDays) {
        // Add the day number to the cell
        cell.innerHTML = dayNum;
        // check the availability of the day and color the cell accordingly
        if (availability[year][month][dayNum]) {
          cell.style.backgroundColor = "green";
        } else {
          cell.style.backgroundColor = "red";
        }
      }
      row.appendChild(cell);
    }
    document.getElementById("calendar").appendChild(row);
  }
}

    </script>
  </head>
  <body onload="generateCalendar()">
    <table>
  <thead>
    <tr>
      <th>Sun</th>
      <th>Mon</th>
      <th>Tue</th>
      <th>Wed</th>
      <th>Thu</th>
      <th>Fri</th>
      <th>Sat</th>
    </tr>
  </thead>
  <tbody id="calendar"></tbody>
</table>
  </body>
</html>
