<?php
session_start();
if (!isset($_SESSION['Admin-name'])) {
  header("location: login.php");
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>DoorLock System</title>
      <link rel="stylesheet" type="text/css" href="css/Users.css">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>

  <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
<style media="screen">
.form-left, .form-right {
  display: inline-block;
  vertical-align: top; /* this is optional, it will align the top of the forms */
}
.table-primary {
  position: sticky;
  top: 0; /* The top property sets the top position of the element */
  background-color: #000; /* This is optional, you can use any background color you want */
}
</style>
</head>
<body id="page-top">
  <?php include'header.php'; ?>
  <div class="container-fluid">
    <h1 class="slideInDown animated">List of Appointments</h1>
      <!--User table-->
      <div class="table-responsive slideInRight animated" style="max-height: 37.5rem">
        <table class="table">
          <thead class="table-primary">
            <tr>
              <th>Name</th>
              <th>Date</th>
              <th>Time-Start</th>
              <th>Time-End</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Action</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody class="table-secondary">
            <br>
         <?php
              //Connect to database
              require'connectDB.php';

                $sql = "SELECT * FROM appointment_tbl WHERE isActive=1 AND date >= CURRENT_DATE ORDER BY date asc";
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_assoc($result))
                {
              ?>
                          <TR>
                          <TD><?php echo $row['name'];?></TD>
                          <TD><?php echo $row['date'];?></TD>
                          <TD><?php echo date("g:ia", strtotime($row['timeStart']));?></TD>
                          <TD><?php echo date("g:ia", strtotime($row['timeEnd']));?></TD>
                          <TD><?php echo $row['reason'];?></TD>

                          <td><span class="pending">Pending</span></td>
                          <td>
                            <form class="form-left" action="update.php" method="post">
                            <input type="hidden" name="appointmentID" value="<?php echo $row['appointmentID'] ?>"
                            <th> <input type ="submit" name="edit" class = "btn btn-success btn-sm "value ="Approve" /></th>
                          </form>
                            <form class="form-right" method="post" onsubmit="return confirmDelete()">
                              <input type="hidden" name="appointmentID" value="<?php echo $row['appointmentID'] ?>"
                              <th>
                                <input type ="submit" name="delete" class="btn btn-danger btn-sm" value="Deny" />
                              </th>
                            </form>
                          </td>
                          <td>
                            <form class="form-left" action="update.php" method="post">
                            <input type="hidden" name="appointmentID" value="<?php echo $row['appointmentID'] ?>"
                            <th> <input type ="submit" name="edit" class = "btn btn-success btn-sm "value ="Edit" /></th>
                          </form>
                            <form class="form-right" method="post" onsubmit="return confirmDelete()">
                              <input type="hidden" name="appointmentID" value="<?php echo $row['appointmentID'] ?>"
                              <th>
                                <input type ="submit" name="delete" class="btn btn-danger btn-sm" value="Cancel" />
                              </th>
                            </form>
                          </td>
                        </TR>
                          <!--<input type ="submit" name="edit" class="btn btn-success" value="Edit" /> -->
                          <!--<button id = "updateAppointmentBtn" type="submit" class="btn btn-primary" data-toggle="modal" data-target="#updateAppointmentModal">Edit</button>-->
            <?php
                    }
            ?>
          </tbody>
        </table>
      </div>
  </div>
  <div class="container-fluid">
    <a class="btn btn-primary" id="historyBtn" href="history.php">History</a>
    <button id = "appoitnmentBtn" type="submit" class="btn btn-primary" data-toggle="modal" data-target="#appointmentModal">New Appointment</button>
  </div>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                  </button>
              </div>
              <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
              <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                  <a class="btn btn-primary" href="login.php">Logout</a>
              </div>
          </div>
      </div>
  </div>


  <!-- Appointment MOdal!-->
  <div class="modal fade" id="appointmentModal" tabindex="-1" role="dialog" aria-labelledby="appointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
  		<form onsubmit="return validateForm()" action="" method="POST" name="addAppointmentFrm" id="addAppointmentFrm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="appointmentModalLabel">Make an Appointment</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
  					<div class="form-group">
  						<label for="name">Name:</label>
  						<input type="text" class="form-control" id="names" name="name" placeholder="Enter name" required>
  					</div>
            <label for="section">Section:</label>
  					<div class="form-group">

  						<!-- <input type="text" class="form-control" id="section" name="section" placeholder="Enter section"> -->
              <select id="section" name="section[]" required multiple style=" width: 462px;">
          						<?php
          							   include 'connectDB.php';
          								 $querySection = "SELECT * FROM section_tbl";
          								 $result = mysqli_query($conn, $querySection);
          								 while($row = mysqli_fetch_assoc($result))
          								 {
          							?>
          							 <option value="<?php echo $row['sectionID']?>"><?php echo $row['sectionName']?> </option>

          							<?php
          						     }
          							?>
          						</select>
  					</div>

  					<div class="form-group">
  						<label for="email">Email:</label>
  						<input type="email" class="form-control" id="emails" name="email" placeholder="Enter email" required>
  					</div>
            <div class="form-group">
              <label for="appointmentDate">Date</label>
              <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" placeholder="Enter date" required>
            </div>

            <div class="form-group">
              <label for="appointmentTimeStart">Time-Start</label>
              <input type="time" min="09:30" max="17:00" class="form-control" id="appointmentTimeStart" name="appointmentTimeStart" placeholder="Enter time" required>
            </div>
  					<div class="form-group">
              <label for="appointmentTimeEnd">Time-End</label>
              <input type="time" min="09:30" max="17:00" class="form-control" id="appointmentTimeEnd" name="appointmentTimeEnd" placeholder="Enter time" required>
            </div>

            <div class="form-group">
              <label for="appointmentNotes">Reason for Appointment</label>
              <textarea class="form-control" id="appointmentNotes" name="appointmentNotes" rows="3" placeholder="Enter any additional notes or details" required></textarea>
            </div>
            <label for="requiredSignatories">Endorsed by</label>

            <div class="form-group">
              <?php
              $sql = "SELECT * FROM prof_tbl";
              $result = mysqli_query($conn, $sql);
            ?>
            <select class="profSelect" name="profSelect" id="profSelect" style="color: #000;">
              <option value="0" selected disabled>List of Professors </option>
              <?php
                require'connectDB.php';
                $sql = "SELECT * FROM prof_tbl ORDER BY profID ASC";
                $result = mysqli_stmt_init($conn);
                if (!mysqli_stmt_prepare($result, $sql)) {
                    echo '<p class="error">SQL Error</p>';
                }
                else{
                    mysqli_stmt_execute($result);
                    $resultl = mysqli_stmt_get_result($result);
                    while ($row = mysqli_fetch_assoc($resultl)){
              ?>
                      <option value="<?php echo $row['profEmail'];?>"><?php echo $row['profName']; ?></option>
              <?php
                    }
                }
              ?>
            </select>
            </div>
            <div class="form-group">
              <label for="requiredSignatories">Signatories</label>
              <input type="checkbox" required checked disabled>Miss A
              <input type="checkbox" required checked disabled>Miss Yanna
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" id="appointmentBtn" name="appointmentBtn" class="btn btn-primary" >Save Appointment</button>
        </div>
      </div>
  	</form>
    </div>
  </div>

  <?php
    include ('connectDB.php');
    if(isset($_POST['appointmentBtn'])){
      $nameTxt = $_POST['name'];
      $emailTxt = $_POST['email'];
      $appointmentDateTxt = date('Y-m-d', strtotime($_POST['appointmentDate']));
      $appointmentTimeStartTxt =$_POST['appointmentTimeStart'];
      $appointmentTimeEndTxt =$_POST['appointmentTimeEnd'];
      $appointmentNotesTxt = $_POST['appointmentNotes'];
      $profSelect = $_POST['profSelect'];
      $appointtedSections = array('');

      // check for overlap
      $checkOverlapQuery = "SELECT * FROM appointment_tbl WHERE date = '$appointmentDateTxt' AND (timeStart <= '$appointmentTimeEndTxt' AND timeEnd >= '$appointmentTimeStartTxt')";
      $overlapResult = mysqli_query($conn, $checkOverlapQuery);

      if (mysqli_num_rows($overlapResult) > 0) {
          // there is an overlap, do not insert the new appointment
          echo  "<script>alert('Sorry, the selected date is fully booked. Please choose a different date.'); setTimeout(function(){ window.location.href='index.php?error=overlap'; }, 200);</script>";
         exit();
      }
       else {
          // no overlap, insert the new appointment
          $addAppointmentQuery = "INSERT INTO `appointment_tbl`(`name`, `email`, `date`, `timeStart`, `timeEnd`,`reason`, `isActive`,`profName`) VALUES ('$nameTxt','$emailTxt','$appointmentDateTxt','$appointmentTimeStartTxt','$appointmentTimeEndTxt','$appointmentNotesTxt', 1,'$profSelect')";
          $result = mysqli_query($conn, $addAppointmentQuery);
          if($result) {
              $id = mysqli_insert_id($conn);
              foreach($_POST['section'] as $sectionTxt) {
                  $addAppointmentSection = "INSERT INTO `appointedsection`(`appointmentId`, `sectionID`) VALUES ('$id','$sectionTxt')";
                  mysqli_query($conn, $addAppointmentSection);
              }
          } else {
              echo "Error";
          }
          echo "<script>window.location.replace('index.php')</script>";

          exit();
      }
    }
  ?>
  <script>
  document.getElementById("historyBtn").addEventListener("click", function(){
      // call the moveToPastAppointments.php file
      fetch("moveToPastAppointments.php")
      .then(response => {
          // after the moveToPastAppointments.php file is called, you can display the past appointments in a table
          return response.text();
      })
      .then(data => {
          // using innerHTML, you can display the past appointments in a table
          document.getElementById("pastAppointmentsTable").innerHTML = data;
      });
  });
  </script>
  <?php
  $conn = mysqli_connect("localhost","root","");
  $db = mysqli_select_db($conn, 'rfidattendance');

  if(isset($_POST['delete']))
  {
    $appointmentID = $_POST['appointmentID'];
    $query = "DELETE FROM appointment_tbl WHERE appointmentID = $appointmentID";
    $query_run = mysqli_query($conn, $query);

    if($query_run){
      echo '<script> alert ("Appointment Cancelled"); </script>';
      echo "<script>window.location.replace('index.php')</script>";
    } else {
      echo '<script> alert ("Appointment not Cancelled"); </script>';
    }
  }
   ?>


  <!-- Modal -->
  <script>
  $(document).ready(function () {
    $("#section").CreateMultiCheckBox({ width: '230px',
               defaultText : 'Select Below', height:'250px' });
  });
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0');
  var yyyy = today.getFullYear();
  today = yyyy + '-' + mm + '-' + dd;
  $('#appointmentDate').attr('min',today);


  function confirmDelete() {
      if (confirm("Are you sure you want to delete this item?")) {
          return true;
      } else {
          return false;
      }
  }

  </script>
  <script>
  function validateForm() {
    var startTime = document.getElementById("appointmentTimeStart").value;
    var endTime = document.getElementById("appointmentTimeEnd").value;

    if (endTime < startTime) {
        alert("End time cannot be less than start time");
        return false;
    }
    return true;
}
  </script>
</body>
</html>
