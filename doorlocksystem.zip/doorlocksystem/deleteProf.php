<?php
include('connectDB.php');
if(isset($_POST['delete']))
{
  $profID = $_POST['profID'];
  $query = "DELETE FROM prof_tbl WHERE profID = $profID";
  $query_run = mysqli_query($conn, $query);

  if($query_run){
    echo '<script> alert ("Professor Removed"); </script>';
    header("location:manageProf.php");
  } else {
    echo '<script> alert ("Professor not Removed"); </script>';
  }
}
 ?>
