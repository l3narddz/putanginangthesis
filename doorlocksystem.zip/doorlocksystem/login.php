<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template-->
    <script src="js/jquery-2.2.3.min.js"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block">
                              <img src="https://truckerpath.com/uploads/2017/11/Trailer-lock.png" width="110%" height="100%" alt="doorlock">
                            </div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                    </div>
                                    <div class = form>
                                      <?php
                                        session_start();
                                        if (isset($_POST['login'])) {
                                            include 'connectDB.php';
                                            if (isset($_POST['username']) && isset($_POST['password'])) {
                                                $username = $_POST['username'];
                                                $password = $_POST['password'];
                                                // Check for a match in the admin table
                                                $query = "SELECT * FROM admin WHERE admin_email = '$username' AND adminPass = '$password'";
                                                $result = mysqli_query($conn, $query);

                                                if (mysqli_num_rows($result) > 0) {
                                                    // A match was found, set session variables and redirect to the admin page
                                                    $_SESSION['username'] = $username;
                                                    $_SESSION['userType'] = "admin";
                                                    header("location: index.php");
                                                    exit();
                                                } else {
                                                    // Check for a match in the prof table
                                                    $query = "SELECT * FROM prof_tbl WHERE profEmail = '$username' AND profPass = '$password'";
                                                    $result = mysqli_query($conn, $query);

                                                    if (mysqli_num_rows($result) > 0) {
                                                        // A match was found, set session variables and redirect to the prof page
                                                        $_SESSION['username'] = $username;
                                                        $_SESSION['userType'] = "prof";
                                                        header("location: indexSignatories.php");
                                                        exit();
                                                    } else {
                                                        // Check for a match in the specific prof table
                                                        $query = "SELECT * FROM head_tbl WHERE email = '$username' AND pass = '$password'";
                                                        $result = mysqli_query($conn, $query);
                                                        if (mysqli_num_rows($result) > 0) {
                                                            // A match was found, set session variables and redirect to the specific prof page
                                                            $_SESSION['username'] = $username;
                                                            $_SESSION['userType'] = "specific_prof";
                                                            header("location: indexMissA.php");
                                                            exit();
                                                        } else {
                                                            // No match was found, display an error message
                                                            echo "<script>alert('Incorrect username or password');</script>";
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        ?>
                                      <form method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <input type="email" name ="username" id="email" class="form-control form-control-user"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Enter Email Address...">
                                                <br>
                                            <input type="password" class="form-control form-control-user" name="password" id="pwd" placeholder="Password" required/>

                                        </div>
                                        <button class="btn btn-primary btn-user btn-block" type="submit" name="login" id="login">login</button>
                                        <hr>
                                      </div>
                                    </div>
                                      </div>
                                        </div>
                                          </div>
                                            </div>
                                              </div>
                                                </div>
                                                  </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
