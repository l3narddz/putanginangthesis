<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Manage Organization</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
        <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/manageorg.css">
    <link rel="stylesheet" type="text/css" href="css/Users.css">
      <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  	<script src="https://code.jquery.com/jquery-3.3.1.js"
  	        integrity="sha1256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  	        crossorigin="anonymous">
  	</script>
      <script type="text/javascript" src="js/bootbox.min.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>

</head>
<body >
  <?php include'header.php'; ?>
  <main>
    <h1>Manage Organization</h1>
  	<div class="form-style-5 slideInDown animated">
  		<form method="POST" name="addOrganizationFrm" id="addOrganizationFrm">
  			<div class="alert_user"></div>
  			<fieldset>
  				<legend><span class="number">1</span> Organization Info</legend>
  				<input type="hidden" name="orgID" id="orgID">
  				<input type="text" name="orgName" id="orgName" placeholder="Organization Name..." required>
  			</fieldset>
  			<fieldset>
  			<label>

          <label for="active"><b>Status</b></label>
  				<input type="radio" name="orgActive" class="active" value="orgActive">Active
  	       <input type="radio" name="orgNotActive" class="active" value="orgNotActive" checked="checked">Not Active
  	      	</label >
  			</fieldset>
  			<button type="submit" id ="addOrgBtn" name="addOrgBtn" class="btn btn-primary">Add Organization</button>
  		</form>
  	</div>

  	<!--User table
  	<div class="section">
  		<div class="slideInRight animated">
  			<div id="manage_users"></div>
  		</div>
  	</div>
    -->

    <div class="section">
        <!--User table-->
        <div class="table-responsive-sm slideInRight animated" style="max-height: 37.5rem">
          <table class="table">
            <thead class="table-primary">
              <tr>
                <th>Name</th>
                <th>Students</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="table-secondary">
              <br>
           <?php
                //Connect to database
                $sql = "SELECT org_tbl.orgName, COUNT(student_tbl.orgName) as org_count, org_tbl.isActive
                          FROM org_tbl
                          LEFT JOIN student_tbl
                          ON org_tbl.orgName = student_tbl.orgName
                          GROUP BY org_tbl.orgName";
                          $result = mysqli_query($conn, $sql);
                          while($row = mysqli_fetch_assoc($result)) { ?>
                          <tr>
                            <td><?php echo $row['orgName']; ?></td>
                            <td><?php echo $row['org_count']; ?></td>
                            <TD><?php echo $row['isActive'];?></TD>
                            <td>
                              <form action="" method="post">
                                <input type="hidden" name="orgID" value="<?php echo $row['orgID'] ?>"
                              <th> <input type ="submit" name="edit" class = "btn btn-success btn-sm "value ="Edit" /></th>
                              <form class="form-right" action="" method="post" onsubmit="return confirmDelete()">
                                <input type="hidden" name="orgID" value="<?php echo $row['orgID'] ?>"
                                <th>
                                  <input type ="submit" name="delete" class="btn btn-danger" value="Delete" />
                                </th>
                              </form>
                            </td>
                            </form>
                          </TR>
                            <!--<input type ="submit" name="edit" class="btn btn-success" value="Edit" /> -->
                            <!--<button id = "updateAppointmentBtn" type="submit" class="btn btn-primary" data-toggle="modal" data-target="#updateAppointmentModal">Edit</button>-->

              <?php
                      }
              ?>
            </tbody>
          </table>
        </div>
    </div>
  </main>
  <?php
    include ('connectDB.php');

    if(isset($_POST['addOrgBtn'])){
      $nameTxt = $_POST['orgName'];
      // echo $nameTxt;

      $addAppointmentQuery = "INSERT INTO `org_tbl`(`orgName`, `isActive`)
      VALUES ('$nameTxt',1)";
      $result = mysqli_query($conn, $addAppointmentQuery);
      if($result)
      {
        echo "Data inserted";
        }
      else {
        echo "Error";
      }
      echo "<script>window.location.replace('manageOrg.php')</script>";

      exit();
    }
  ?>
  <?php
  include('connectDB.php');
  if(isset($_POST['delete']))
  {
    $orgID = $_POST['orgID'];
    $query = "DELETE FROM org_tbl WHERE orgID = $orgID";
    $query_run = mysqli_query($conn, $query);

    if($query_run){
      echo "<script>window.location.replace('manageOrg.php')</script>";
    } else {
      echo '<script> alert ("Data has not been deleted"); </script>';
    }
  }
   ?>

  <script type="text/javascript">
  function confirmDelete() {
      if (confirm("Are you sure you want to delete this item?")) {
          return true;
      } else {
          return false;
      }
  }
  </script>
</body>
</html>
