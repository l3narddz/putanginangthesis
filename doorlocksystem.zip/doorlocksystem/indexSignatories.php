<?php
session_start();
if (!isset($_SESSION['prof_tbl-profName'])) {
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>DoorLock System</title>
      <link rel="stylesheet" type="text/css" href="css/Users.css">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/1658d4fd0c.js" crossorigin="anonymous"></script>
  <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
<style media="screen">
.form-left, .form-right {
  display: inline-block;
  vertical-align: top; /* this is optional, it will align the top of the forms */
}
.table-primary {
  position: sticky;
  top: 0; /* The top property sets the top position of the element */
  background-color: #000; /* This is optional, you can use any background color you want */
}
</style>
</head>
<body id="page-top">
    <?php include'headerSignatories.php'; ?>
    <?php
      require 'connectDB.php';
      $profName = $_SESSION['username']; //get the currently logged in prof's name
      $query = "SELECT * FROM appointment_tbl WHERE profName='$profName' AND isActive=1";
      $result = mysqli_query($conn, $query);
      ?>
      <div class="container-fluid">

<div class="table-responsive slideInRight animated" style="max-height: 37.5rem">
    <table class="table">
        <thead class="table-primary">
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Time Start</th>
                <th>Time End</th>
                <th>Reason</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody class="table-secondary">
            <?php
            if (mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>
                          <td>".$row['name']."</td>
                          <td>".$row['date']."</td>
                          <td>".$row['timeStart']."</td>
                          <td>".$row['timeEnd']."</td>
                          <td>".$row['reason']."</td>
                          <td>
                              <form class='form-left' method='post'>
                                  <input type='hidden' name='appointmentID' value='".$row['appointmentID']."'>
                                  <input type='submit' name='approve' class='btn btn-success btn-sm' value='Approve'>
                                  </form>
                                  <form class='form-right' method='post' onsubmit='return confirmDelete()'>
                                  <input type='hidden' name='appointmentID' value='".$row['appointmentID']."'>
                                  <input type='submit' name='delete' class='btn btn-danger btn-sm' value='Deny' onClick='return confirm('Are you sure you want to cancel the appointment?');'>
                                  </form>
                                  </td>
                                  </tr>";
                                    }
                                    } else {
                                    echo "<tr><td colspan='6'>No appointments found for this prof.</td></tr>";
                                    }
                                    ?>
        </tbody>
    </table>
    </div>
          </div>
          <?php

          if(isset($_POST['delete']))
          {
            $appointmentID = $_POST['appointmentID'];
            $query = "DELETE FROM appointment_tbl WHERE appointmentID = $appointmentID";
            $query_run = mysqli_query($conn, $query);

            if($query_run){
              echo '<script> alert ("Appointment Cancelled"); </script>';
              echo "<script>window.location.replace('indexSignatories.php')</script>";
            } else {
              echo '<script> alert ("Appointment not Cancelled"); </script>';
            }
          }
           ?>
  <!-- Logout Modal-->

  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                  </button>
              </div>
              <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
              <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                  <a class="btn btn-primary" href="login.php">Logout</a>
              </div>
          </div>
      </div>
  </div>

  <script>
      function confirmDelete() {
          return confirm("Are you sure you want to cancel the appointment?");
      }
  </script>
</body>
</html>
