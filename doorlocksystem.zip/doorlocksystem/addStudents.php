<?php
  include ('connectDB.php');

  if(isset($_POST['addStudentBtn'])){
    $studNum = $_POST['studentNumber'];
    $fname = $_POST['firstName'];
    $lname = $_POST['lastName'];
    $secID =$_POST['sectionSelect'];
    $org =$_POST['orgSelect'];
    // echo $nameTxt;

    $addAppointmentQuery = "INSERT INTO `student_tbl`(`studentNumber`, `firstName`, `lastName`, `sectionID`,`orgName`)
    VALUES ('$studNum','$fname','$lname','$secID','$org')";
    $result = $conn->query($addAppointmentQuery);
    if($result)
    {
      echo "Data inserted";
      }
    else {
      echo "Error";
    }
    header("Location: manageStudents.php");
    exit();
  }
?>
